/*
Exemple de librairie pouvant etre ajoute au projet
*/
#include <libExample.h>

// Class constructor
MyClass::MyClass(){
    
}

// Class desstructor
MyClass::~MyClass(){
    
}

// Public Functions
void MyClass::myPublicFunction(){

}

// Private Functions
void MyClass::myPrivateFunction(){

}

// Protected Functions
void MyClass::myProtectedFunction(){

}